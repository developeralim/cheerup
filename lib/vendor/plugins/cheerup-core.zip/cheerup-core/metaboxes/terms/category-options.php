<?php
/**
 * Options for category / term meta.
 */
$options = [
	[
		'label'   => esc_html_x('Category Image', 'Admin', 'cheerup'),
		'name'    => 'image', // will be _bunyad_image
		'desc'    => esc_html_x('This image may be used on category archives and also when needed in a category list block.', 'Admin', 'cheerup'),
		'type'    => 'upload',
		'options' => [
			'type'         => 'image',
			'title'        => esc_html_x('Upload This Picture', 'Admin', 'cheerup'), 
			'button_label' => esc_html_x('Upload', 'Admin', 'cheerup'),
			'insert_label' => esc_html_x('Use as Category Image', 'Admin', 'cheerup'),
			'media_type'   => 'id',
		],
		'value' => '' // default
	],
];

return $options;